def my_func(a,b):
        '''
>>> my_func(2,3)
5767
        '''
        return a + b

print (my_func(2,3))   #calling a function


"""
#run as
#>> python -m doctest -v doctest_ex.py


testcode
pre defined module doctest  , it uses docString '''   '''

"""
