"""glob -this module provides a function for making file lists from directory wildcard searches
"""

import glob
print ("All file listing with extension py :\n", glob.glob('*.txt'))
