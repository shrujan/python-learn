import math
print ('The value of PI is approximately %5.3f.' % math.pi)
print ("Sqrt of 25 = ", math.sqrt(25))
print (math.pow(2,3))
