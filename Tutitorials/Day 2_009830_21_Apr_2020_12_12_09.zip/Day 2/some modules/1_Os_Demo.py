
import os
#os.system('echo $HOME')
os.system('cls')
print ("Good Bye 2019!!!!")
print ("AAA")
print ("----------------------------------------------------")
print (dir(os))
#then execute 2_Sys_Command_line_arg_demo_4.py also
