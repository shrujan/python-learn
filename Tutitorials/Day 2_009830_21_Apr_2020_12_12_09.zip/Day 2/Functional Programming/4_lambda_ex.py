
print (lambda:1)    #this loads  a function without any name anonymous  , after : is the return value
print ("----------------------------------------------------")


a= (lambda:1)
print ("a = ",a)
print("return value of lambda = ", a())    #function getting called\






























