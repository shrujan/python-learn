#Example: while loop

count = 0
while (count < 5):
    print ('the index is:', count)
    count = count + 1

print ("END!!!!")

#while  True:
#   pass
    
