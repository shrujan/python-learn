
#Variable number of Positional arguments (non-keyword arguments)
#def tupleVarArgs(*theRest, arg1, arg2='defausltB'):   #Syntax Error
def tupleVarArgs(arg1, arg2='defaultB',*theRest):   #*theRest is tuple can cosume only non-keyword argumnet  ('xyz', 456.789)

    """varaible argumnets"""
    print ('formal arg 1:', arg1)
    print ('formal arg 2:', arg2)
    print ("theRest tuple = ",theRest)   #  whole tuple is printed   ('xyz', 456.789)
    for eachXtrArg in theRest:
        print ('another arg:', eachXtrArg)
#calling functions        
tupleVarArgs('abc', 123, 'xyz', 456.789)       #this works   non-keyword arguments passed
print ("----------------------------------------------------")

tupleVarArgs('abc', 123, [1,2,3],['A','b'])                                         #works
print ("----------------------------------------------------")
tupleVarArgs('abc',123, arg4 = 'xyz')  #run time Typeerror    arg4 = 'xyz'--->keyword argument
print ("----------------------------------------------------")
tupleVarArgs('abc')                                                                 #this works *theRest tuple willbe empty


"""
num1 =  100   #int  id = 789654   int is immutable

num1 = 999    ##int  id = 755555


num1 = "PSL"   #str

arg2 = "deafaultB"  #str
arg2 = 123 #123
"""















"""
print "----------------------------------------------------"

tupleVarArgs('abc', 123, 'xyz')
t1 = (1,)
print "t1 =", t1

l1 =[10]
print "l1 = ",l1[0]
"""
