#!C:/Program Files (x86)/Python373
#First line is a shebang which tells the shell about location of Python interpreter
print ("Learning Python") #print function prints an expression on the console
print ('Hello World')
print ("END!!!!")
