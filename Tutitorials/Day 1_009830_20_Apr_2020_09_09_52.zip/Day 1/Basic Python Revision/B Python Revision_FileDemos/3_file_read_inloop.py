



#f = open('data11.txt', "r")   #by default read mode
#f = open('data11.txt')   #by default read mode #IOError:
f = open('data.txt', "r")   #by default read mode #IOError:
for line in f:
        print (line)
f.close()
"""
print (dir(f))
print ("_"*45)
while True:
        char = f.read(1)
        if not char: break
        print (char)
f.close()
"""






"""
#as opposed to
for char in open('data.txt').read():
        print char
"""
