#Read empdata.txt, store it in appropriate data structure
#display all line in sorted manner on name
#display the total Salary

#empdata ={'ABC':[25,25000], 'XYZ':[35,35000]}
fh =open("EmpData.txt")
empData = {}
for line in fh:
    line = line.rstrip()
    listData = line.split(":")
    empData[listData[0]] = listData[1:]
names = empData.keys()
names = list(names)
names.sort()
print ("-----------------------------------------------")
totalSal=0
for i in names:
    print ("Name = ", i , " Details = ", empData[i])
    totalSal += int(empData[i][1])
print ("-----------------------------------------------")

    
    
