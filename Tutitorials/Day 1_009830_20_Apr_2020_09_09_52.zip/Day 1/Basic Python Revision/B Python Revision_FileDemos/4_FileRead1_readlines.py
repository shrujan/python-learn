

fin=open('data.txt','r')
data =fin.readlines()   #list
#print data
for line in data:
    print (line)
fin.close()



"""
list1 =[1,55,99]
print list1[-2]
print list1[0]

"""
