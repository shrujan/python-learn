f = open ("empdata.txt", "r")
empData = {}
for line in f:
    #print "Line = ", line
    line = line.rstrip()
    datalist = line.split(":")   #["1a","ABC","25","25000"]
    empData[datalist[0]] = datalist[1:4]        #created a pair in dict
print ("EmpData dict = ",empData)   #dictionary of inner list
k1 = empData.keys()
k1 = list(k1)
k1.sort()
totalSal = 0
print ("-----------------------------------------------")
print ("All employee details =")
for i in k1:
    print ("Emp Id ", i , " details are :")
    print ("\t Name : ", empData [i][0])
    print ("\t Age : ", empData [i][1])
    print ("\t Sal : ", empData [i][2])
    totalSal += int(empData [i][2])
print ("-----------------------------------------------")
print ("Total sal of all emp = ",totalSal)



#empData = {'1a':["ABC",25,25000]}


#print f.read()
