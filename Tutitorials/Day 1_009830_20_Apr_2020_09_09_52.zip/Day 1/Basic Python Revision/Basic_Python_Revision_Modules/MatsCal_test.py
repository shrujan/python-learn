


from MathsCal import *
print ("Area = ",area(5))


"""
import MatsCal
MathsCal.mymath.area(4)
"""
