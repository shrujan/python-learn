from Birds import Birds
from Mammals import Mammals




















#import Birds
#b1 = Birds.Birds()
#importing Mammals class from Mammals module file
"""
Writting final application
b1 = Birds()
b1. printm()
"""
