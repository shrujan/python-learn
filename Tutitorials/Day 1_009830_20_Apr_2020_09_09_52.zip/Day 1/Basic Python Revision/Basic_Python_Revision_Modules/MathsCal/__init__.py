

from mymath import *
