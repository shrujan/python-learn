
#from mymath import pi, area
from mymath import *
#pi =100
print ("pi = ", pi)
print ("area = ",area(5))
fib(21)    #NameError


#from mymath import *

#from mymath import pi


