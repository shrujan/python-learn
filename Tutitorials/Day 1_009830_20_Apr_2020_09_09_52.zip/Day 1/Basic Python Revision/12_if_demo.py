#Example : if loop

a=20
b=20
if (a<b):print ("a is less than b")
elif(a>b):
    print ("a is greater than b")

else:
    print ("a is less than  b")
