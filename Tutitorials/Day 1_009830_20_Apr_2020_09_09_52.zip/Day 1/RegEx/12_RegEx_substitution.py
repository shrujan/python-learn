

#12_RegEx_substitution.py
import re

s1 = "Welcome to PSL, PSL in Pune, Psl  psl"

subs2 = re.sub("PSL","Persistent",s1)
print ("Original string = ", s1) #Welcome to Persistent, Persistent in Pune
print ("Replaced string = ", subs2)#Welcome to Persistent, Persistent in Pune, Psl  psl
print ("----------------------------------------------")

subs3 = re.sub("PSL","Persistent",s1, flags=re.I)
print ("Replaced string = ", subs3)#Welcome to Persistent, Persistent in Pune, Persistent  Persistent
print ("----------------------------------------------")

subs4 = re.sub("PSL","Persistent",s1, flags=re.I, count=1)#Welcome to Persistent, PSL in Pune, Psl  psl
print ("Replaced string = ", subs4)
print ("----------------------------------------------")











"""
string = "If the the problem is textual, use the the re module"
print ("Original string = ",string) #Original string =  If the the problem is textual, use the the re module
pattern = r"the the"
regexp = re.compile(pattern)
str1=regexp.sub("the", string)
print ("Modified string = ",str1)    #Modified string =  If the problem is textual, use the re module

"""










"""
Assignment
accept price field from a user(keyboard i/p)
Validate it for below rules-
1. it should begin with $
2. followed with at least 1 disgit
3. then decimal point .
4. then exact 2 number of digits after the decimal point


print the valid price field

price = "$1.55"       valid
price = "$.55"         Not valid
price = "$1.34555"      Not valid
"""










































       
